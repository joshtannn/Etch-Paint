(() => {
  'use strict';

  const canvas = document.querySelector('#paintCanvas');
  const ctx = canvas.getContext('2d', { alpha: true });
  const wrap = document.querySelector('#canvasWrap');
  const hint = document.querySelector('#canvasHint');
  const status = document.querySelector('#liveStatus');
  const coordinates = document.querySelector('#coordinates');
  const brushButton = document.querySelector('#brushTool');
  const eraserButton = document.querySelector('#eraserTool');
  const sizeSlider = document.querySelector('#brushSize');
  const sizeValue = document.querySelector('#sizeValue');
  const undoButton = document.querySelector('#undoButton');
  const redoButton = document.querySelector('#redoButton');
  const clearButton = document.querySelector('#clearButton');
  const saveButton = document.querySelector('#saveButton');
  const openButton = document.querySelector('#openStudio');
  const customColor = document.querySelector('#customColor');

  const LOGICAL_WIDTH = 1200;
  const LOGICAL_HEIGHT = 700;
  const state = {
    tool: 'brush',
    color: '#173d36',
    size: Number(sizeSlider.value),
    drawing: false,
    activePointer: null,
    activeStroke: null,
    history: [],
    redo: [],
    hasMarks: false,
  };

  function setStatus(message) {
    status.innerHTML = `<span class="status-dot" aria-hidden="true"></span> ${message}`;
  }

  function setCanvasResolution() {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(LOGICAL_WIDTH * ratio);
    canvas.height = Math.round(LOGICAL_HEIGHT * ratio);
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    redraw();
  }

  function getPoint(event) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(LOGICAL_WIDTH, (event.clientX - rect.left) * LOGICAL_WIDTH / rect.width)),
      y: Math.max(0, Math.min(LOGICAL_HEIGHT, (event.clientY - rect.top) * LOGICAL_HEIGHT / rect.height)),
    };
  }

  function drawStroke(stroke) {
    if (!stroke || stroke.points.length === 0) return;
    ctx.save();
    ctx.globalCompositeOperation = stroke.tool === 'eraser' ? 'destination-out' : 'source-over';
    ctx.strokeStyle = stroke.color;
    ctx.fillStyle = stroke.color;
    ctx.lineWidth = stroke.size;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    const points = stroke.points;
    if (points.length === 1) {
      ctx.beginPath();
      ctx.arc(points[0].x, points[0].y, stroke.size / 2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length; i += 1) ctx.lineTo(points[i].x, points[i].y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function redraw() {
    ctx.clearRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    for (const action of state.history) {
      if (action.type === 'clear') ctx.clearRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
      else drawStroke(action);
    }
    state.hasMarks = state.history.some((action, index) => {
      if (action.type === 'clear') return false;
      return !state.history.slice(index + 1).some(next => next.type === 'clear');
    });
    hint.classList.toggle('is-hidden', state.hasMarks || state.drawing);
    undoButton.disabled = state.history.length === 0;
    redoButton.disabled = state.redo.length === 0;
  }

  function appendPoint(point) {
    if (!state.activeStroke) return;
    const points = state.activeStroke.points;
    points.push(point);
    if (points.length > 1) {
      const previous = points[points.length - 2];
      drawStroke({ ...state.activeStroke, points: [previous, point] });
    } else {
      drawStroke(state.activeStroke);
    }
    state.hasMarks = true;
    hint.classList.add('is-hidden');
  }

  function beginStroke(event) {
    if (event.button !== undefined && event.button !== 0) return;
    event.preventDefault();
    canvas.focus({ preventScroll: true });
    canvas.setPointerCapture(event.pointerId);
    state.drawing = true;
    state.activePointer = event.pointerId;
    state.activeStroke = {
      type: 'stroke',
      tool: state.tool,
      color: state.color,
      size: state.size,
      points: [],
    };
    appendPoint(getPoint(event));
    setStatus(state.tool === 'eraser' ? 'Erasing…' : 'Drawing…');
  }

  function moveStroke(event) {
    if (!state.drawing || event.pointerId !== state.activePointer) return;
    event.preventDefault();
    const point = getPoint(event);
    coordinates.textContent = `X ${String(Math.round(point.x)).padStart(4, '0')} · Y ${String(Math.round(point.y)).padStart(4, '0')}`;
    appendPoint(point);
  }

  function endStroke(event) {
    if (!state.drawing || event.pointerId !== state.activePointer) return;
    if (state.activeStroke && state.activeStroke.points.length) {
      state.history.push(state.activeStroke);
      state.redo = [];
    }
    state.drawing = false;
    state.activePointer = null;
    state.activeStroke = null;
    try { canvas.releasePointerCapture(event.pointerId); } catch (_) { /* Capture may already be released. */ }
    setStatus(state.tool === 'eraser' ? 'Eraser ready' : 'Brush ready');
    redraw();
  }

  function chooseTool(tool) {
    state.tool = tool;
    const brushActive = tool === 'brush';
    brushButton.classList.toggle('is-active', brushActive);
    eraserButton.classList.toggle('is-active', !brushActive);
    brushButton.setAttribute('aria-pressed', String(brushActive));
    eraserButton.setAttribute('aria-pressed', String(!brushActive));
    wrap.classList.toggle('is-erasing', !brushActive);
    setStatus(brushActive ? 'Brush ready' : 'Eraser ready');
  }

  function chooseColor(color) {
    state.color = color;
    document.querySelectorAll('.swatch').forEach(button => {
      const selected = button.dataset.color.toLowerCase() === color.toLowerCase();
      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
  }

  function undo() {
    if (!state.history.length) return;
    state.redo.push(state.history.pop());
    redraw();
    setStatus('Last action undone');
  }

  function redo() {
    if (!state.redo.length) return;
    state.history.push(state.redo.pop());
    redraw();
    setStatus('Action restored');
  }

  function clearCanvas() {
    if (!state.history.length) return;
    state.history.push({ type: 'clear' });
    state.redo = [];
    redraw();
    setStatus('Canvas cleared · undo to restore');
  }

  function savePng() {
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = LOGICAL_WIDTH;
    exportCanvas.height = LOGICAL_HEIGHT;
    const exportContext = exportCanvas.getContext('2d');
    exportContext.fillStyle = '#ffffff';
    exportContext.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    exportContext.drawImage(canvas, 0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
    exportCanvas.toBlob(blob => {
      if (!blob) {
        setStatus('Could not create PNG');
        return;
      }
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'etch-paint-drawing.png';
      link.click();
      URL.revokeObjectURL(link.href);
      setStatus('PNG saved');
      window.setTimeout(() => setStatus(state.tool === 'eraser' ? 'Eraser ready' : 'Brush ready'), 1800);
    }, 'image/png');
  }

  function updateBrushSize() {
    state.size = Number(sizeSlider.value);
    sizeValue.value = String(state.size);
    sizeValue.textContent = String(state.size);
  }

  canvas.addEventListener('pointerdown', beginStroke);
  canvas.addEventListener('pointermove', moveStroke);
  canvas.addEventListener('pointerup', endStroke);
  canvas.addEventListener('pointercancel', endStroke);
  canvas.addEventListener('pointerleave', () => {
    if (!state.drawing) coordinates.textContent = 'X 0000 · Y 0000';
  });
  brushButton.addEventListener('click', () => chooseTool('brush'));
  eraserButton.addEventListener('click', () => chooseTool('eraser'));
  sizeSlider.addEventListener('input', updateBrushSize);
  document.querySelectorAll('.swatch').forEach(button => button.addEventListener('click', () => chooseColor(button.dataset.color)));
  customColor.addEventListener('input', () => chooseColor(customColor.value));
  undoButton.addEventListener('click', undo);
  redoButton.addEventListener('click', redo);
  clearButton.addEventListener('click', clearCanvas);
  saveButton.addEventListener('click', savePng);
  openButton.addEventListener('click', () => {
    document.querySelector('#studio').scrollIntoView({ behavior: 'smooth', block: 'start' });
    window.setTimeout(() => canvas.focus({ preventScroll: true }), 350);
  });

  document.addEventListener('keydown', event => {
    const target = event.target;
    const isTyping = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target.isContentEditable;
    if (isTyping) return;
    const key = event.key.toLowerCase();
    const command = event.ctrlKey || event.metaKey;
    if (command && key === 'z' && event.shiftKey) {
      event.preventDefault();
      redo();
    } else if (command && key === 'z') {
      event.preventDefault();
      undo();
    } else if (command && key === 'y') {
      event.preventDefault();
      redo();
    } else if (!command && key === 'b') {
      chooseTool('brush');
    } else if (!command && key === 'e') {
      chooseTool('eraser');
    } else if (key === '[') {
      sizeSlider.value = String(Math.max(Number(sizeSlider.min), state.size - 2));
      updateBrushSize();
    } else if (key === ']') {
      sizeSlider.value = String(Math.min(Number(sizeSlider.max), state.size + 2));
      updateBrushSize();
    }
  });

  window.addEventListener('resize', setCanvasResolution);
  setCanvasResolution();
  updateBrushSize();
})();
