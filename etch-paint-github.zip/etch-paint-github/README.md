# Etch / Paint

A small, dependency-free drawing app built from the “Interactive & Data” project card. Draw on a responsive canvas with a mouse, touchscreen, or stylus; switch tools and colors; undo, redo, clear, and export your drawing as a PNG.

## Run it locally

You can open `index.html` directly in a modern browser. For a local server, open a terminal in this folder and run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Keyboard controls

| Key | Action |
| --- | --- |
| `B` | Brush |
| `E` | Eraser |
| `[` / `]` | Decrease / increase brush size |
| `Ctrl` or `⌘` + `Z` | Undo |
| `Ctrl` or `⌘` + `Shift` + `Z` | Redo |
| `Ctrl` or `⌘` + `Y` | Redo |

## Publish with GitHub Pages

1. Create a GitHub repository and upload the contents of this folder.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, select **GitHub Actions**.
4. Push to the `main` branch. The included workflow publishes the static site.

No build step or package installation is required. The canvas stores strokes as normalized drawing coordinates so it remains sharp on high-density displays and redraws cleanly when the window resizes. The history stack powers undo, redo, and clear.

## Project files

- `index.html` — semantic page structure and accessible controls
- `style.css` — responsive layout and visual design
- `app.js` — pointer input, canvas rendering, keyboard shortcuts, history, and PNG export
- `.github/workflows/pages.yml` — deploys the site to GitHub Pages

## License

MIT. See [LICENSE](LICENSE).
