# CPE 2300 Etch / Paint — RISC-V Project

This repository organizes the team’s Etch / Paint term project. The target is a single RISC-V assembly program that runs in the course Playground. The program is intended to poll supported keyboard/pointer inputs, map positions into a framebuffer, and draw marks that remain visible.

## Academic integrity and source code

The project workbook says the team must write its own assembly and that AI-generated assembly violates course policy. This repository contains no generated `.s` file. Add one team-authored `.s` source file at the repository root after your team writes and tests it. Each member should be able to explain their routines for the individual coding challenge and viva.

Do not assume input controls, memory addresses, or simulator behavior. Confirm them in the course Playground/MustyV instructions.

## Project documents

- [Block/system diagram](docs/block-system-diagram.svg) (also available as a [PNG for Google Drawings](docs/block-system-diagram.png))
- [Program flowchart](docs/flowchart.mmd)
- [Test plan](docs/TEST-PLAN.md)
- [Weekly progress prompts](docs/WEEKLY-REPORTS.md)
- [Final report template](docs/PROJECT-REPORT-TEMPLATE.md)

## Core objectives

1. Poll the simulator’s documented pointer and keyboard inputs.
2. Map drawing input to valid framebuffer coordinates and render a brush mark.
3. Preserve earlier marks while responding to new input.

## Optional features

- Keyboard-controlled color selection.
- Keyboard-controlled clear action using C if the simulator supports it, or another confirmed key.

## Team responsibilities

Replace these role labels with names in the workbook and report.

- **Member 1 — graphics/framebuffer:** confirm the display interface; write and test initialization, clearing, and brush-mark routines.
- **Member 2 — input/coordinates:** confirm controls; write and test input polling, coordinate mapping, and bounds handling.
- **Member 3 — main loop/integration:** connect team-written routines, handle the repeated loop and agreed keyboard commands, and coordinate integration/tests.

All weekly reports, contributions, results, screenshots, and challenges must describe work that actually happened.

## Final submission checklist

- One `.s` file that assembles and runs in the course Playground.
- A PDF report containing the 10 required sections in `docs/PROJECT-REPORT-TEMPLATE.md`.
- Test results and screenshots from actual runs.
- The project workbook’s weekly reports and final summary.
